<script setup>
</script>

<template>
      <div class="container d-flex justify-content-center align-items-center">
    <div class="card" style="width: 23rem; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);">
      <img
        src="../assets/img/user2.jpeg"
        class="card-img-top rounded-circle mx-auto mt-3"
        alt="Profile Picture"
        style="width: 200px; height: 200px;"
      />
      <div class="card-body text-center">
        <h5 class="card-title">Lâm Minh Nhật</h5>
        <p class="card-text text-muted">PC09537</p>
        <p class="card-text">Lập trình website
        </p>
        <div class="d-flex justify-content-center">
          <a href="#" class="text-dark mx-2"><i class="fab fa-facebook fa-lg"></i></a>
          <a href="#" class="text-dark mx-2"><i class="fab fa-twitter fa-lg"></i></a>
          <a href="#" class="text-dark mx-2"><i class="fab fa-linkedin fa-lg"></i></a>
          <a href="#" class="text-dark mx-2"><i class="fab fa-github fa-lg"></i></a>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped></style>